CARDVAULT WEBSITE FOUNDATION - PART 5

HOW TO VIEW
1. Download and unzip cardvault-part5.zip.
2. Open the cardvault folder.
3. Double-click index.html to open the homepage in a browser.

FOLDER STRUCTURE
cardvault/
  index.html
  shop-cards.html
  sports.html
  about.html
  landing-page.html
  sign-up.html
  thank-you.html
  collecting-guides.html
  css/styles.css
  images/ (local SVG artwork)

NOTES
- The site uses a shared external stylesheet.
- Navigation links connect to real pages in this folder.
- The layout uses CSS Grid and Flexbox with responsive media queries.
- The sign-up form is a front-end prototype. It routes to thank-you.html but does not save account data.
- The artwork is original SVG placeholder artwork and can be replaced with real card images later.
- collecting-guides.html is included as an early foundation page and can be expanded in Part 6.
